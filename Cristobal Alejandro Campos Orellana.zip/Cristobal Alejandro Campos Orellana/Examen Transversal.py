#===Sistema de administracion de cinemax
# ---------------------------------------------------------------------
# Funciones de validación de datos
# ---------------------------------------------------------------------
def leer_opcion():
    
    try:
        opcion = int(input("Ingrese opción: "))
        if 1 <= opcion <= 6:
            return opcion
        else:
            print("Debe seleccionar una opción válida")
            return None
    except ValueError:
        print("Debe seleccionar una opción válida")
        return None

def buscar_codigo(codigo, cartelera):
   
    
    return codigo.upper() in cartelera


# ---------------------------------------------------------------------
# Opcion 1: Cupos por genero
# ---------------------------------------------------------------------
def cupos_genero(genero, peliculas, cartelera):
    
    total_cupos = 0
    genero_buscar = genero.lower()
    
    
    for cod, datos in peliculas.items():
        if datos[1].lower() == genero_buscar:
            
            total_cupos += cartelera[cod][1]
            
    print(f"El total de cupos disponibles es: {total_cupos}")


#---------------------------------------------------------------------
# Opcion 2: Busqueda de peliculas por rango de precio
#---------------------------------------------------------------------
def busqueda_precio(p_min, p_max, peliculas, cartelera):
    resultados = []
    
    for cod, datos_cartelera in cartelera.items():
        precio = datos_cartelera[0]
        cupos = datos_cartelera[1]
        
        if p_min <= precio <= p_max and cupos > 0:
            titulo = peliculas[cod][0]
            resultados.append(f"{titulo}--{cod}")
            
    if not resultados:
        print("No hay películas en ese rango de precios.")
    else:
        
        resultados.sort()
        print(f"Las películas encontradas son: {resultados}")


#---------------------------------------------------------------------
# Opcion 3: Actualizar precio de una pelicula
#---------------------------------------------------------------------
def actualizar_precio(codigo, nuevo_precio, cartelera):
    
    cod_upper = codigo.upper()
    if buscar_codigo(cod_upper, cartelera):
        cartelera[cod_upper][0] = nuevo_precio
        return True
    return False


#---------------------------------------------------------------------
# Opcion 4: Agregar pelicula
#---------------------------------------------------------------------
def validar_codigo(codigo, cartelera):
    if not codigo.strip() or buscar_codigo(codigo, cartelera):
        return False
    return True

def validar_titulo(titulo):
    return bool(titulo.strip())

def validar_genero(genero):
    return bool(genero.strip())

def validar_duracion(duracion_str):
    try:
        duracion = int(duracion_str)
        return duracion > 0
    except ValueError:
        return False

def validar_clasificacion(clasificacion):
    return clasificacion.strip().upper() in ['A', 'B', 'C']

def validar_idioma(idioma):
    return bool(idioma.strip())

def validar_es_3d(es_3d_str):
    return es_3d_str.strip().lower() in ['s', 'n']

def validar_precio(precio_str):
    try:
        precio = int(precio_str)
        return precio > 0
    except ValueError:
        return False

def validar_cupos(cupos_str):
    try:
        cupos = int(cupos_str)
        return cupos >= 0
    except ValueError:
        return False

def agregar_pelicula(codigo, titulo, genero, duracion, clasificacion, idioma, es_3d, precio, cupos, peliculas, cartelera):
    
    cod_upper = codigo.upper()
    if buscar_codigo(cod_upper, cartelera):
        return False
        
    
    es_3d_bool = True if es_3d.lower() == 's' else False
    
    # Inserción en Estructuras
    peliculas[cod_upper] = [titulo, genero, int(duracion), clasificacion.upper(), idioma, es_3d_bool]
    cartelera[cod_upper] = [int(precio), int(cupos)]
    return True


#---------------------------------------------------------------------
# Opcion 5: Eliminar pelicula
#---------------------------------------------------------------------
def eliminar_pelicula(codigo, peliculas, cartelera):
    
    cod_upper = codigo.upper()
    if buscar_codigo(cod_upper, cartelera):
        del peliculas[cod_upper]
        del cartelera[cod_upper]
        return True
    return False


#---------------------------------------------------------------------
# Programa principal
#---------------------------------------------------------------------
def main():
    
    peliculas = {
        'P101': ['Luz de Otoño', 'drama', 110, 'B', 'Español', False],
        'P102': ['Noche Neón', 'acción', 125, 'C', 'Ingles', True],
        'P103': ['Planeta Agua', 'documental', 90, 'A', 'Español', False],
        'P104': ['Risa Total', 'comedia', 105, 'A', 'Español', True],
        'P105': ['Código Zero', 'thriller', 118, 'C', 'Ingles', True],
        'P106': ['Viaje Lunar', 'ciencia ficción', 132, 'B', 'Ingles', False]
    }

    cartelera = {
        'P101': [5990, 40],
        'P102': [7990, 0],
        'P103': [4990, 25],
        'P104': [6990, 12],
        'P105': [8990, 8],
        'P106': [7490, 3]
    }

    
    ejecutando = True
    while ejecutando:
        print("\n========== MENÚ PRINCIPAL ==========")
        print("1. Cupos por genero")
        print("2. Búsqueda de películas por rango de precio")
        print("3. Actualizar precio de película")
        print("4. Agregar película")
        print("5. Eliminar película")
        print("6. Salir")
        print("=====================================")
        
        opcion = leer_opcion()
        
        if opcion is None:
            continue
            
        # --- OPCIÓN 1 ---
        if opcion == 1:
            gen = input("Ingrese género a consultar: ")
            cupos_genero(gen, peliculas, cartelera)
            
        # --- OPCIÓN 2 ---
        elif opcion == 2:
            while True:
                try:
                    p_min = int(input("Ingrese precio mínimo: "))
                    p_max = int(input("Ingrese precio máximo: "))
                    if p_min >= 0 and p_max >= 0 and p_min <= p_max:
                        break
                    else:
                        print("Debe ingresar valores enteros válidos (mínimo menor o igual al máximo).")
                except ValueError:
                    print("Debe ingresar valores enteros")
            
            busqueda_precio(p_min, p_max, peliculas, cartelera)
            2
        # --- OPCIÓN 3 ---
        elif opcion == 3:
            continuar = 's'
            while continuar.lower() == 's':
                cod = input("Ingrese código de película: ")
                try:
                    n_precio = int(input("Ingrese nuevo precio: "))
                    if n_precio <= 0:
                        print("El precio debe ser un valor entero positivo.")
                        continue
                except ValueError:
                    print("Debe ingresar un valor entero válido.")
                    continue
                
                
                if actualizar_precio(cod, n_precio, cartelera):
                    print("Precio actualizado")
                else:
                    print("El código no existe")
                    
                continuar = input("¿Desea actualizar otro precio (s/n)?: ")
                
        # --- OPCIÓN 4 ---
        elif opcion == 4:
            cod = input("Ingrese código de película: ")
            if not validar_codigo(cod, cartelera):
                print("Error: Código inválido o ya existente.")
                continue
                
            tit = input("Ingrese título: ")
            if not validar_titulo(tit):
                print("Error: Título inválido.")
                continue
                
            gen = input("Ingrese género: ")
            if not validar_genero(gen):
                print("Error: Género inválido.")
                continue
                
            dur = input("Ingrese duración (minutos): ")
            if not validar_duracion(dur):
                print("Error: Duración inválida.")
                continue
                
            cla = input("Ingrese clasificación: ")
            if not validar_clasificacion(cla):
                print("Error: Clasificación inválida.")
                continue
                
            idi = input("Ingrese idioma: ")
            if not validar_idioma(idi):
                print("Error: Idioma inválido.")
                continue
                
            formato_3d = input("¿Es 3D? (s/n): ")
            if not validar_es_3d(formato_3d):
                print("Error: Entrada 3D inválida.")
                continue
                
            prc = input("Ingrese precio: ")
            if not validar_precio(prc):
                print("Error: Precio inválido.")
                continue
                
            cup = input("Ingrese cupos: ")
            if not validar_cupos(cup):
                print("Error: Cupos inválidos.")
                continue
            
           
            if agregar_pelicula(cod, tit, gen, dur, cla, idi, formato_3d, prc, cup, peliculas, cartelera):
                print("Película agregada")
            else:
                print("El código ya existe")
                
        # --- OPCIÓN 5 ---
        elif opcion == 5:
            cod = input("Ingrese código de película que desea eliminar: ")
            if eliminar_pelicula(cod, peliculas, cartelera):
                print("Película eliminada")
            else:
                print("El código no existe")
                
        # --- OPCIÓN 6 ---
        elif opcion == 6:
            print("Programa finalizado")
            ejecutando = False

if __name__ == "__main__":
    main()